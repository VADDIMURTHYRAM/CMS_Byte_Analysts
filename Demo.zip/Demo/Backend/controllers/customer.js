//Import Customer Model
import Customer from "../models/customer.js";

//Get all Customers
export const getCustomers = async (req,res) => {
    try {
        const customer = await Customer.findAll();
        res.send(customer);
    } catch (err) {
        console.log(err);
    }
}

//Get contact by id
export const getCustomerById = async (req,res) => {
    try {
        const customer = await Customer.findAll({
            where: {
                id: req.params.id
            }
        });
        res.send(customer[0]);
    } catch (err) {
        console.log(err);
    }
}

//Create a new contact
export const createContact = async (req,res) => {
    try {
        await Customer.create(req.body);
        res.json({
            "message": "Contact Created"
        });
    } catch (err) {
        console.log(err);
    }
}

// Update contact by id
export const updateContact = async (req, res) => {
    try {
        await Customer.update(req.body, {
            where: {
                id: req.params.id
            }
        });
        res.json({
            "message": "Contact Updated"
        });
    } catch (err) {
        console.log(err);
    }
}

//Delete contact by id
export const deleteContact = async (req,res) => {
    try {
        await Customer.destroy({
            where: {
                id: req.params.id
            }
        });
        res.json({
            "message": "Contact Deleted"
        });
    } catch (err) {
        console.log(err);
    }
}