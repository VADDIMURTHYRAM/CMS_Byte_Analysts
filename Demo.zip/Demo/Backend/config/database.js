//import sequelize
import { Sequelize } from "sequelize";

//create connection
const db = new Sequelize ('customer_database','Bindu','Bindu@2404',{dialect: 'mssql', server: 'INCOIBYERRAPATR\\SQLEXPRESS', port: 55814});

//export connection
export default db;