//import express
import express from "express";
//import product controller
import {
    getCustomers,
    getCustomerById,
    createContact,
    updateContact,
    deleteContact
} from "../controllers/customer.js";

//Init express router
const router = express.Router();

//Get all customers
router.get('/customers', getCustomers);
//Get customer by id
router.get('/customers/:id', getCustomerById);
//Create contact
router.post('/customers', createContact);
//Update contact
router.put('/customers/:id', updateContact);
// delete contact
router.delete('/customers/:id', deleteContact);

// export router
export default router;