//import sequelize
import { Sequelize } from "sequelize";
//import connection
import db from "../config/database.js";

//init Datatypes
const { DataTypes } = Sequelize;

//Define schema
const Customer = db.define('customers', {
    Customer_Name: {
       type: Sequelize.STRING,
       allowNull: false
    },
    DOB: {
       type: Sequelize.DATE,
    },
    Addr: {
       type: Sequelize.STRING,
       allowNull: false
    },
    City: {
       type: Sequelize.STRING,
       allowNull: false
    },
    PinCode: {
       type: Sequelize.INTEGER,
    },
    Contact: {
       type: Sequelize.INTEGER,
    },
    Email: {
        type: Sequelize.STRING,
        allowNull: false
     }
   },{
    tableName: "customers"
   });

   export default Customer;