import './SearchandData.css';

function SearchandData(){
    return(
        <div className="Search">
            <p>Customer Management System</p>
            <input type="text"/>
            <button className="search_button">Search</button>
        </div>
);
}
export default SearchandData;